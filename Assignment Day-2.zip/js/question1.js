//to find c
let name="caleb joshua";
console.log(name.charAt(1));