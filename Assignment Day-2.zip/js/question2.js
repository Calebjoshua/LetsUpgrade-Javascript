let minutes=2;
let seconds=60*minutes;
console.log("the seconds for given"+" "+minutes+" "+"minutes is"+" "+seconds+" "+"seconds");