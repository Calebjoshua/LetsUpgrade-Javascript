//to search the elements index
let num=[1,5,7,3,2,8];
console.log(num.indexOf(2));