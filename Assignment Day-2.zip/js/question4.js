// function contains(arr, element) {
//     for (var i = 0; i < arr.length; i++) {
//         if (element==arr[i]. {
//             console.log(element);
//         }
//     }
// }
// arr = [2, 5, 59, 6];
// console.log(contains(arr, 5))
var fruits=["apple","lemon","mango"];
let fruits1=[];
fruits.includes(charAt('a'));
console.log(fruits);
