let names1=["caleb","joshua","john","cena","virat","kohli"];
for(let i=names1.length-1;i>=0;i--){
    console.log(names1[i]);
}